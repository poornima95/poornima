export class Employee {
  constructor(
   public id: string,
     public name: string,
	 public gender: string,
	  public role: string,
	  public hobbies: any[],
	   public status: string,
	    public date: string,
		

   
 ){}//DELETE FROM `crud` WHERE `id`=0
 //form value is posting null in angular 2 in xampp
	
    
}