import {Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class CrudService {
employees=[];
constructor (private _http: Http) {}
view(){
return this._http.get("http://localhost/api/view.php")
.map(res=>res.json());

}
addemp(info){
    
return this._http.post("http://localhost/api/insert.php",info)
.map(()=>"");
}

	  
 getemp(id){
    return this._http.post("http://localhost/api/selectone.php/",{'id':id})
      .map(res=>res.json());
  }
  delemp(delarr){
    return this._http.post("http://localhost/api/delete.php/",[delarr])
      .map(()=>this.view());
  }
   updateEmployee(info){
    return this._http.post("http://localhost/api/update.php/", info)
      .map(()=>"");
  }

}