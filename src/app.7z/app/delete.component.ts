import { Component } from '@angular/core';

@Component ({
   selector: 'app-root',
   template: 'delete',
})
export   class   AppDelete  {
}