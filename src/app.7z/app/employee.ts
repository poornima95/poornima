export class Employee
{
  emp_name:string;
   
}