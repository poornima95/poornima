import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AppView } from './view.component';
import { AppInsert } from './insert.component';
import { AppEdit } from './edit.component';
import { AppDelete } from './delete.component';
import { AppUpdate } from './update.component';
import {HttpClientModule} from '@angular/common/http';

const appRoutes: Routes = [
   { path: 'view', component: AppView },
   { path: 'insert', component: AppInsert },
   { path: 'edit', component: AppEdit },
   { path: 'delete', component: AppDelete },
   { path: 'update/:id', component: AppUpdate}
];

@NgModule({
  declarations: [
    AppComponent,
    AppView,
    AppInsert,
    AppEdit,
    AppDelete,
	AppUpdate
	
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
	HttpClientModule,
   RouterModule.forRoot(appRoutes)
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }